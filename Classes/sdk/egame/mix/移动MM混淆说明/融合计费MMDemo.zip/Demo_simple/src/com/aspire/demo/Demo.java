package com.aspire.demo;

import mm.yp.purchasesdk.OnSMSPurchaseListener;
import mm.yp.purchasesdk.PayInfo;
import mm.yp.purchasesdk.YPPurchase;
import mm.yp.purchasesdk.fingerprint.IdentifyApp;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

public class Demo extends Activity implements OnClickListener {
	/** Called when the activity is first created. */
	public static final int ITEM0 = Menu.FIRST;// 系统值
	private final String TAG = "Demo";

	public YPPurchase purchase;
	private Context context;

	private Button billButton;
	private ProgressDialog mProgressDialog;

	private Button productButton;
	
	private EditText mPaycodeView;
	private IAPListener mListener;

	private static final String LEASE_PAYCODE = "000000000000";

	private static final String PUT_CHANNEL = "";
	private String mPaycode;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

	
		mProgressDialog = new ProgressDialog(Demo.this);
		mProgressDialog.setIndeterminate(true);
		mProgressDialog.setMessage("请稍候...");
		context = Demo.this;

		mPaycode = readPaycode();
		/**
		 * IAP组件初始化.包括下面2步。
		 */
		/**
		 * step1.实例化PurchaseListener。实例化传入的参数与您实现PurchaseListener接口的对象有关。
		 * 例如，此Demo代码中使用IAPListener继承PurchaseListener，其构造函数需要Context实例。
		 */
		mListener = new IAPListener( this );
		/**
		 * step2.获取Purchase实例。
		 */
		purchase = YPPurchase.getInstance();
		
		billButton = (Button) findViewById(R.id.billing);
		billButton.setOnClickListener(this);
		productButton = (Button) findViewById(R.id.product);
		productButton.setOnClickListener(this);
		
	}

	@Override
	public void onClick(View v) {
		int id = v.getId();
		switch (id) {
		case R.id.billing:
			showProgressDialog();
			/**
			 * 商品购买接口。
			 */
			order(this, mListener);
			break;
		case R.id.product:
			try {
				System.out.println("mPaycode:" + mPaycode);
				PayInfo info = purchase.getPayInfo(Demo.this, mPaycode );
				System.out.println("info =" + info.toString());
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		default:
			break;
		}

	}

	public void order(Context context, OnSMSPurchaseListener listener) {
		try {
			purchase.order(context, mPaycode, listener, PUT_CHANNEL,null );
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void showProgressDialog() {
		if (mProgressDialog == null) {
			mProgressDialog = new ProgressDialog(Demo.this);
			mProgressDialog.setIndeterminate(true);
			mProgressDialog.setMessage("请稍候.....");
		}
		if (!mProgressDialog.isShowing()) {
			mProgressDialog.show();
		}
	}

	public void dismissProgressDialog() {
		if (mProgressDialog != null && mProgressDialog.isShowing()) {
			mProgressDialog.dismiss();
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		menu.add(0, ITEM0, 0, "修改商品信息");
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {

		switch (item.getItemId()) {
		case ITEM0:
			LayoutInflater inflater = getLayoutInflater();
			View layout = inflater.inflate(R.layout.dialog,
					(ViewGroup) findViewById(R.id.dialog));
			mPaycodeView = (EditText) layout.findViewById(R.id.paycode);
			mPaycodeView.setText(readPaycode());
			new AlertDialog.Builder(this).setTitle("商品ID").setView(layout)
					.setPositiveButton("确定", mOkListener)
					.setNegativeButton("取消", null).show();
			break;
		default:

			break;
		}
		return super.onOptionsItemSelected(item);
	}

	private final static String PAYCODE = "Paycode";

	private void savePaycode(String paycode) {
		Editor sharedata = getSharedPreferences("data", 0).edit();
		sharedata.putString(PAYCODE, paycode);
		sharedata.commit();
	}

	private String readPaycode() {
		SharedPreferences sharedPreferences = getSharedPreferences("data", 0);
		String paycode = sharedPreferences.getString(PAYCODE, LEASE_PAYCODE);
		return paycode;
	}

	private DialogInterface.OnClickListener mOkListener = new DialogInterface.OnClickListener() {

		@Override
		public void onClick(DialogInterface dialog, int which) {
			if (mPaycodeView != null) {
				String paycode = mPaycodeView.getText().toString().trim();
				savePaycode(paycode);
				mPaycode = paycode;
			}
		}
	};

	public void showDialog(String title, String msg) {
		AlertDialog.Builder builder = new AlertDialog.Builder(context);
		builder.setTitle(title);
		builder.setIcon(context.getResources().getDrawable(R.drawable.icon));
		builder.setMessage((msg == null) ? "Undefined error" : msg);
		builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int whichButton) {
				dialog.dismiss();
			}
		});
		builder.create().show();
	}
}